<?php
/**
 * @package loginaudit
 */
class auditLog extends xPDOSimpleObject {}