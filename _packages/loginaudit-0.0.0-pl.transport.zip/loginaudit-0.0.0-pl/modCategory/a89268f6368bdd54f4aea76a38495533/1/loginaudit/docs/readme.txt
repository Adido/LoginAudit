--------------------
Login Audit
--------------------
Version: 1.0.0
Maintainer: Mark Willis <mark.willis@adi.do>
--------------------

Login Audit records all users logging into and out of the manager. This is then downloadable as a CSV.


Formz has two dependencies which need to be installed first. The dependencies are both
available through the MODX Package Management tool.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/Adido/loginAudit/issues
