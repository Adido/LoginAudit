<?php
/**
 * loginaudit
 */
/**
 * Default English Lexicon Entries for loginaudit
 *
 * @package loginaudit
 * @subpackage lexicon
 */
$_lang['loginaudit'] = 'Login Audit';
$_lang['loginaudit.top'] = 'Login Audit';
$_lang['loginaudit.intro_msg'] = 'Below is a list of all users who have logged in and out of the manager';
$_lang['loginaudit.menu_desc'] = 'Manager Login Report';

$_lang['loginaudit.form.action'] = 'Action';
$_lang['loginaudit.form.actionDate'] = 'Action Date';
